#include "game.h"
#include "global.h"
#ifndef GENERATE_CELL
#define GENERATE_CELL
void generate_cell();
#endif // GENERATE CELL
