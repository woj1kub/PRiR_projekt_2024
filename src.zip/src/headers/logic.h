#ifndef LOGIC
#define LOGIC
#include "global.h"
void logic();

#endif // LOGIC