#ifndef RANDOMS
#define RANDOMS
int generate_random_number(int min, int max);
#endif